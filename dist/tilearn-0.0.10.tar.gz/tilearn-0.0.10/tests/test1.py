import tilearn as tl
import process as pc

x = [[1, 2, 3, 6, 3],[2, 4, 8, 4, 2],[2, 4, 8, 6, 7],[2, 4, 8, 4, 2],[2, 4, 8, 4, 2]]

print(tilearn.factor_data(x, 10))