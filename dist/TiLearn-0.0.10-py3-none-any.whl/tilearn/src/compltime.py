from tilearn import *

x = [[1, 2, 3],
     [2, 4, 8],
     [2, 4, 8]]

print(job_amout(x))

#def non_pre(a):
#    for i in range(job_amount(a)):  
        